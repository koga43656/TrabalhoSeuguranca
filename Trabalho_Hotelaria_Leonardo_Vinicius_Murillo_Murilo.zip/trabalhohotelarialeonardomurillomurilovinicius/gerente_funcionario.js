

class Gerente {
    constructor(id, nome, senha) {
        this.id = id;
        this.nome = nome;
        this.senha = senha;
    }
}

class GerenteManager {
    constructor() {
        this.gerentesIniciais = [
            new Gerente(1, "koga", "sddsmaryclare"),
            new Gerente(2, "mu borges", "sophia777"),
            new Gerente(3, "vini banos", "estadolover"),
            new Gerente(4, "mu santos", "sociologoraiamsantos")
        ];
    }

    async gerarHashSenha(senha) {
        const encoder = new TextEncoder();
        const data = encoder.encode(senha);
        const hashBuffer = await crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    async inicializarGerentes() {
        const gerentes = this.carregarGerentes();
        if (gerentes.length === 0) {
            console.log('Nenhum gerente encontrado. Salvando os iniciais...');
            // Criptografa as senhas dos gerentes iniciais antes de salvar
            const gerentesCriptografados = await Promise.all(this.gerentesIniciais.map(async (gerente) => {
                const senhaCriptografada = await this.gerarHashSenha(gerente.senha);
                return new Gerente(gerente.id, gerente.nome, senhaCriptografada);
            }));
            this.salvarGerentes(gerentesCriptografados);
        }
        this.atualizarTabelaGerentes();  // Atualiza a tabela logo após a inicialização
    }

    carregarGerentes() {
        return JSON.parse(localStorage.getItem("gerentes")) || [];
    }

    salvarGerentes(gerentes) {
        localStorage.setItem("gerentes", JSON.stringify(gerentes));
    }

    validarEntrada(entrada) {
        if (entrada.includes("'") || entrada.includes('"')) {
            return false;
        }
        return true;
    }

    async loginGerente(nome, senha) {
        
        if (!this.validarEntrada(nome) || !this.validarEntrada(senha)) {
            alert("Os caracteres ' e \" não são permitidos.");
            return;
        }
    
        
        const gerentes = this.carregarGerentes();
        const gerente = gerentes.find(g => g.nome === nome);

        if (!gerente) {
            alert("Nome ou senha incorretos.");
            return;
        }

        try {
            const hashSenha = await this.gerarHashSenha(senha);
            if (hashSenha === gerente.senha) {
                alert(`Bem-vindo, ${gerente.nome}! (ID: ${gerente.id})`);
                window.location.href = "ident.html";
            } else {
                alert("Senha incorreta.");
            }
        } catch (error) {
            console.error("Erro ao gerar o hash da senha:", error);
        }
    }

    async adicionarGerente(id, nome, senha) {
        
        if (!this.validarEntrada(nome) || !this.validarEntrada(senha)) {
            alert("Os caracteres ' e \" não são permitidos.");
            return;
        }

        if (!id || isNaN(id) || id <= 0) {
            alert("Por favor, insira um ID válido (um número positivo).");
            return;
        }

        if (!id || !nome || !senha) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        const gerentes = this.carregarGerentes();

        const gerenteExistente = gerentes.find(g => g.id === id || g.nome === nome);
        if (gerenteExistente) {
            alert("Este ID ou nome de gerente já existe. Escolha outro.");
            return;
        }

        try {
            const hashSenha = await this.gerarHashSenha(senha);
            gerentes.push(new Gerente(id, nome, hashSenha));
            this.salvarGerentes(gerentes);
            this.atualizarTabelaGerentes();
        } catch (error) {
            console.error("Erro ao gerar o hash da senha:", error);
        }
    }

    removerGerente(index) {
        if (confirm("Você tem certeza que deseja remover este gerente?")) {
            const gerentes = this.carregarGerentes();
            gerentes.splice(index, 1);
            this.salvarGerentes(gerentes);
            this.atualizarTabelaGerentes();
        }
    }

    atualizarTabelaGerentes() {
        const tabela = document.getElementById("listaGerentes").getElementsByTagName("tbody")[0];
        tabela.innerHTML = "";  // Limpa a tabela antes de adicionar os gerentes
    
        const gerentes = this.carregarGerentes();  // Carrega os gerentes do localStorage
    
        // Verifica se há dados para exibir
        if (gerentes.length === 0) {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = "Nenhum gerente encontrado";
            return;
        }
    
        // Exibe os gerentes na tabela
        gerentes.forEach((gerente, index) => {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = gerente.id ? gerente.id : "ID não encontrado";
            row.insertCell(1).innerText = gerente.nome;
    
            const acaoCell = row.insertCell(2);
            const botaoRemover = document.createElement("button");
            botaoRemover.innerText = "Remover";
            botaoRemover.onclick = () => this.removerGerente(index);
            acaoCell.appendChild(botaoRemover);
        });
    }
}

// Instancia o GerenteManager
const gerenteManager = new GerenteManager();


// Função de login do gerente
async function loginGerenteHandler(event) {
    event.preventDefault();
    const nome = document.getElementById("nomeGerente").value;
    const senha = document.getElementById("senhaGerente").value;
    await gerenteManager.loginGerente(nome, senha);
}

// Função de adicionar gerente
async function adicionarGerenteHandler(event) {
    event.preventDefault();
    const id = Number(document.getElementById("id").value);
    const nome = document.getElementById("nomeGerente").value;
    const senha = document.getElementById("senhaGerente").value;
    await gerenteManager.adicionarGerente(id, nome, senha);
    gerenteManager.atualizarTabelaGerentes();  // Atualiza a tabela após adicionar
}

class Funcionario {
    constructor(id, nome, cargo, senha) {
        this.id = id;
        this.nome = nome;
        this.cargo = cargo;
        this.senha = senha;
    }
}

class FuncionarioManager {
    constructor() {
        this.funcionariosIniciais = [
            { id: 1, nome: "fernando", cargo: "Recepcionista", senha: "papairma" },
            { id: 2, nome: "kaio", cargo: "Recepcionista", senha: "aiquesaldadedaminhaex" }
        ];
    }

    async gerarHashSenha(senha) {
        const encoder = new TextEncoder();
        const data = encoder.encode(senha);
        const hashBuffer = await crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    async inicializarFuncionarios() {
        let funcionarios = this.carregarFuncionarios();
        if (funcionarios.length === 0) {
            console.log("Nenhum funcionário encontrado. Salvando os iniciais...");
            
            // Gera hashes para as senhas dos funcionários iniciais
            funcionarios = await Promise.all(
                this.funcionariosIniciais.map(async (funcionario) => {
                    const hashSenha = await this.gerarHashSenha(funcionario.senha);
                    return new Funcionario(funcionario.id, funcionario.nome, funcionario.cargo, hashSenha);
                })
            );

            this.salvarFuncionarios(funcionarios);
        }
        this.atualizarTabelaFuncionarios(); // Atualiza a tabela logo após a inicialização
    }

    carregarFuncionarios() {
        return JSON.parse(localStorage.getItem("funcionarios")) || [];
    }

    salvarFuncionarios(funcionarios) {
        localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
    }

    validarEntrada(entrada) {
        if (entrada.includes("'") || entrada.includes('"')) {
            return false;
        }
        return true;
    }

    async loginFuncionario(nome, senha) {
        if (!this.validarEntrada(nome) || !this.validarEntrada(senha)) {
            alert("Os caracteres ' e \" não são permitidos.");
            return;
        }
        
        const funcionarios = this.carregarFuncionarios();
        const funcionario = funcionarios.find(f => f.nome === nome);

        if (!funcionario) {
            alert("Nome ou senha inválidos. Tente novamente.");
            return;
        }

        try {
            const hashSenha = await this.gerarHashSenha(senha);
            if (hashSenha === funcionario.senha) {
                alert(`Login bem-sucedido! Bem-vindo, ${funcionario.nome}`);
                window.location.href = "indexfuncionario.html";
            } else {
                alert("Senha incorreta.");
            }
        } catch (error) {
            console.error("Erro ao gerar o hash da senha:", error);
        }
    }

    async registrarFuncionario(id, nome, cargo, senha) {
        if (!this.validarEntrada(nome) || !this.validarEntrada(senha)) {
            alert("Os caracteres ' e \" não são permitidos.");
            return;
        }
        
        if (!id || isNaN(id) || id <= 0) {
            alert("Por favor, insira um ID válido (um número positivo).");
            return;
        }
        
        if (!id || !nome || !cargo || !senha) {
            alert("Por favor, preencha todos os campos corretamente!");
            return;
        }

        const funcionarios = this.carregarFuncionarios();
        if (funcionarios.find(f => f.id === id)) {
            alert("Este ID já está cadastrado. Por favor, escolha outro ID.");
            return;
        }

        try {
            const hashSenha = await this.gerarHashSenha(senha);
            const funcionario = new Funcionario(id, nome, cargo, hashSenha);
            funcionarios.push(funcionario);
            this.salvarFuncionarios(funcionarios);
            this.atualizarTabelaFuncionarios();  // Atualiza a tabela após o registro
        } catch (error) {
            console.error("Erro ao gerar o hash da senha:", error);
        }
    }

    removerFuncionario(index) {
        if (confirm("Você tem certeza que deseja remover este funcionário?")) {
            const funcionarios = this.carregarFuncionarios();
            funcionarios.splice(index, 1);
            this.salvarFuncionarios(funcionarios);
            this.atualizarTabelaFuncionarios();  // Atualiza a tabela após remoção
        }
    }

    atualizarTabelaFuncionarios() {
        const tabela = document.getElementById("listaFuncionarios").getElementsByTagName("tbody")[0];
        tabela.innerHTML = "";  // Limpa a tabela antes de adicionar os funcionários
    
        const funcionarios = this.carregarFuncionarios();  // Carrega os funcionários do localStorage
    
        // Verifica se há dados para exibir
        if (funcionarios.length === 0) {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = "Nenhum funcionário encontrado";
            return;
        }
    
        // Exibe os funcionários na tabela
        funcionarios.forEach((funcionario, index) => {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = funcionario.id;
            row.insertCell(1).innerText = funcionario.nome;
            row.insertCell(2).innerText = funcionario.cargo;
    
            const acaoCell = row.insertCell(3);
            const botaoRemover = document.createElement("button");
            botaoRemover.innerText = "Remover";
            botaoRemover.onclick = () => this.removerFuncionario(index);
            acaoCell.appendChild(botaoRemover);
        });
    }
}

// Inicializa os gerentes e funcionários quando a página for carregada
const funcionarioManager = new FuncionarioManager();


// Função de login do funcionário
async function loginFuncionarioHandler(event) {
    event.preventDefault();
    const nome = document.getElementById("nomeFuncionario").value;
    const senha = document.getElementById("senhaFuncionario").value;
    await funcionarioManager.loginFuncionario(nome, senha);
}

// Função de registrar funcionário
async function registrarFuncionarioHandler(event) {
    event.preventDefault();
    const id = Number(document.getElementById("idFuncionario").value);
    const nome = document.getElementById("nomeFuncionario").value;
    const cargo = document.getElementById("cargoFuncionario").value;
    const senha = document.getElementById("senhaFuncionario").value;
    await funcionarioManager.registrarFuncionario(id, nome, cargo, senha);
    funcionarioManager.atualizarTabelaFuncionarios();  // Atualiza a tabela após adicionar
}

window.onload = () => {
    
    try {
        gerenteManager.inicializarGerentes();
    } catch (error) {
        console.error("Erro ao inicializar gerentes:", error);
    }

    try {
        funcionarioManager.inicializarFuncionarios();
    } catch (error) {
        console.error("Erro ao inicializar funcionários:", error);
    }
};