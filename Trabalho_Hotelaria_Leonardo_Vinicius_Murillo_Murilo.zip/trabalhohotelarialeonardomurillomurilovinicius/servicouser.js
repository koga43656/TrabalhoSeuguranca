let servicos = JSON.parse(localStorage.getItem("servicos")) || [];
let comprasHospede = [];
let totalCompras = 0;

function carregarServicos() {
    const tabela = document.getElementById("listaServicos").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    servicos.forEach((servico) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = servico.id;
        row.insertCell(1).innerText = servico.nome;
        row.insertCell(2).innerText = `R$ ${servico.preco.toFixed(2)}`;
        const acaoCell = row.insertCell(3);
        const botaoComprar = document.createElement("button");
        botaoComprar.innerText = "Comprar";
        botaoComprar.onclick = () => comprarItem(servico);
        acaoCell.appendChild(botaoComprar);
    });
}

function comprarItem(servico) {
    comprasHospede.push(servico);
    totalCompras += servico.preco;
    atualizarCompras();
}

function atualizarCompras() {
    const listaCompras = document.getElementById("listaCompras");
    const totalPagar = document.getElementById("totalPagar");

    listaCompras.innerHTML = "";
    comprasHospede.forEach(item => {
        const listItem = document.createElement("li");
        listItem.innerText = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        listaCompras.appendChild(listItem);
    });
    totalPagar.innerText = `Total a Pagar: R$ ${totalCompras.toFixed(2)}`;
}

function finalizarConsumo() {
    const nomeHospede = prompt("Insira seu nome para finalizar o consumo:");
    if (!nomeHospede) return;

    let servicosHospede = JSON.parse(localStorage.getItem("servicosHospede")) || {};

    if (!servicosHospede[nomeHospede]) {
        servicosHospede[nomeHospede] = [];
    }

    servicosHospede[nomeHospede] = servicosHospede[nomeHospede].concat(comprasHospede);

    localStorage.setItem("servicosHospede", JSON.stringify(servicosHospede));
    alert("Consumo finalizado.");
}

window.onload = carregarServicos;