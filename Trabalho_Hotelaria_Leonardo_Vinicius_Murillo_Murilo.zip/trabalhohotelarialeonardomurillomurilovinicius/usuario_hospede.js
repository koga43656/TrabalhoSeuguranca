class Usuario {
    constructor(nome, email, senha, endereco, cpf) {
        this.id = null;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
        this.cpf = cpf;
    }

    static carregarUsuarios() {
        return JSON.parse(localStorage.getItem("usuarios")) || [];
    }

    static salvarUsuarios(usuarios) {
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
    }

    static carregarReservas() {
        return JSON.parse(localStorage.getItem("reservas")) || [];
    }

    static irParaCadastro() {
        window.location.href = "cadastro.html";
    }

    static irParaCadastroHospede() {
        window.location.href = "reservausuario.html";
    }


    static validarEntrada(entrada) {
        if (entrada.includes("'") || entrada.includes('"')) {
            return false;
        }
        return true;
    }

    // Função para gerar o hash da senha usando SHA-256
    static async gerarHashSenha(senha) {
        const encoder = new TextEncoder();
        const data = encoder.encode(senha);
        const hashBuffer = await crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    static async cadastrarUsuario(event) {
        event.preventDefault();

        const nome = document.getElementById("nomeUsuario").value;
        const email = document.getElementById("emailUsuario").value;
        const senha = document.getElementById("senhaUsuario").value;
        const endereco = document.getElementById("enderecoUsuario").value;
        const cpf = document.getElementById("cpfUsuario").value;

        const usuarios = Usuario.carregarUsuarios();

        if (!Usuario.validarEntrada(nome) || !Usuario.validarEntrada(email) || !Usuario.validarEntrada(senha) || !Usuario.validarEntrada(endereco) || !Usuario.validarEntrada(cpf)) {
            alert("Os campos não podem conter os caracteres ' ou \"");
            return;
        }
        
        // Validar o email
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailRegex.test(email)) {
            alert("Por favor, insira um email válido com '@' e '.com'.");
            return;
        }
        
        // Validar a senha
        if (senha.length <= 6) {
            alert("A senha deve ter mais de 6 caracteres.");
            return;
        }
        
        // Validar o endereço
        const enderecoRegex = /^(Rua|Avenida)\s/;
        if (!enderecoRegex.test(endereco)) {
            alert("O endereço deve começar com 'Rua' ou 'Avenida'.");
            return;
        }
        
        // Validar o CPF (11 dígitos numéricos)
        const cpfRegex = /^\d{11}$/;
        if (!cpfRegex.test(cpf)) {
            alert("Por favor, insira um CPF válido com exatamente 11 dígitos numéricos.");
            return;
        }

        if (usuarios.some(usuario => usuario.nome === nome)) {
            alert("Já existe um usuário com este nome. Escolha outro nome.");
            return;
        }
        if (usuarios.some(usuario => usuario.cpf === cpf)) {
            alert("Já existe um usuário com este CPF. Verifique o número informado.");
            return;
        }

        try {
            // Gerar hash da senha
            const hashSenha = await Usuario.gerarHashSenha(senha);

            const novoId = usuarios.length > 0 ? Math.max(...usuarios.map(usuario => usuario.id)) + 1 : 0;

            const novoUsuario = new Usuario(nome, email, hashSenha, endereco, cpf);
            novoUsuario.id = novoId;

            usuarios.push(novoUsuario);
            Usuario.salvarUsuarios(usuarios);

            alert("Usuário cadastrado com sucesso!");
            document.getElementById("formCadastro").reset();
            window.location.href = "loginusuario.html";
        } catch (error) {
            console.error("Erro ao gerar o hash da senha:", error);
            alert("Ocorreu um erro ao cadastrar o usuário. Tente novamente.");
        }
    }

    static async fazerLogin(event) {
        event.preventDefault();

        const nome = document.getElementById("nomeUsuario").value;
        const senha = document.getElementById("senhaUsuario").value;

        const usuarios = Usuario.carregarUsuarios();

        const usuario = usuarios.find(u => u.nome === nome);

        if (!usuario) {
            alert("Usuário não encontrado.");
            return;
        }

        try {
            // Gerar hash da senha informada para comparação
            const hashSenha = await Usuario.gerarHashSenha(senha);

            if (hashSenha === usuario.senha) {
                alert("Login bem-sucedido! Bem-vindo, " + usuario.nome);
                window.location.href = "indexusuario.html";
            } else {
                alert("Senha incorreta. Tente novamente.");
            }
        } catch (error) {
            console.error("Erro ao verificar a senha:", error);
            alert("Ocorreu um erro ao fazer login. Tente novamente.");
        }
    }

    static async fazerLoginHospede(event) {
        event.preventDefault();

        const nome = document.getElementById("nomeHospede").value;
        const senha = document.getElementById("senhaHospede").value;
        const reservas = Usuario.carregarReservas();

        // Busca a reserva do hóspede pelo nome
        const reserva = reservas.find(r => r.nomeUsuario === nome);

        if (!reserva) {
            alert("Reserva não encontrada.");
            return;
        }

        try {
            // Gerar hash da senha informada para comparação
            const hashSenha = await Usuario.gerarHashSenha(senha);

            if (hashSenha === reserva.senhaUsuario) {
                alert("Login bem-sucedido! Bem-vindo, " + reserva.nomeUsuario);
                window.location.href = "indexhospede.html"; 
            } else {
                alert("Senha inválida. Tente novamente.");
            }
        } catch (error) {
            console.error("Erro ao verificar a senha:", error);
            alert("Ocorreu um erro ao fazer login. Tente novamente.");
        }
    }
}

