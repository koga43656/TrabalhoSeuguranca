const reservas = JSON.parse(localStorage.getItem("reservas")) || [];
const pedidos = JSON.parse(localStorage.getItem("pedidos")) || [];

function fazerPedido(servico) {
    const nome = prompt("Digite seu nome:");
    if (!nome) {
        alert("Nome não pode ser vazio!");
        return;
    }

    
    const reservaCliente = reservas.find(reserva => reserva.nomeUsuario === nome);
    if (!reservaCliente) {
        alert("Nome não encontrado na lista de reservas. Pedido não permitido.");
        return;
    }

    
    const numeroQuarto = reservaCliente.numeroQuarto;
    const pedido = {
        cliente: nome,
        servico,
        numeroQuarto
    };

    pedidos.push(pedido);
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
    alert(`Pedido de "${servico}" registrado para ${nome} no quarto ${numeroQuarto}.`);
}